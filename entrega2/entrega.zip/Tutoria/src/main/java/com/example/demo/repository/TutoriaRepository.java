package com.example.demo.repository;



import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.demo.model.Tutoria;



public interface TutoriaRepository extends MongoRepository<Tutoria, String>{

	
}
